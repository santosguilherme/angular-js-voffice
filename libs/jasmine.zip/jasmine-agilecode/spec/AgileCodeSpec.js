describe("AgileCode Specification", function () {
	it("Should work!", function () {
	  expect(true).toBe(true);
	});
});